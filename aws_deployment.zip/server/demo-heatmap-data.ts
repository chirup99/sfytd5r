// Demo heatmap data removed - no hardcoded local data
// All journal data comes from AWS DynamoDB only

export const DEMO_HEATMAP_DATA: Record<string, any> = {};

export function getDemoHeatmapData(): Record<string, any> {
  return {};
}

export function seedDemoDataToAWS(): Record<string, any> {
  return {};
}
