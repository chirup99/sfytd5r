# AWS Elastic Beanstalk Deployment Guide

## Prerequisites
- AWS Account with Elastic Beanstalk access
- AWS CLI installed (optional but recommended)
- EB CLI installed: `pip install awsebcli`

## Quick Deployment Steps

### Step 1: Extract the ZIP file
```bash
unzip trading-app-aws.zip
cd eb-deploy
```

### Step 2: Initialize EB (First time only)
```bash
eb init -p "Node.js 20 running on 64bit Amazon Linux 2" --region us-east-1
```

### Step 3: Create Environment
```bash
eb create trading-app-env
```

### Step 4: Set Environment Variables
Via AWS Console:
1. Go to Elastic Beanstalk → Environment → Configuration
2. Under "Environment Properties", add:
   - `NODE_ENV` = `production`
   - `PORT` = `5000`
   - `ANGEL_ONE_CLIENT_ID` = your value
   - `ANGEL_ONE_PASSWORD` = your value
   - `ANGEL_ONE_TOTP_KEY` = your value
   - `ZERODHA_API_KEY` = your value
   - `ZERODHA_SECRET_KEY` = your value
   - `GEMINI_API_KEY` = your value

### Step 5: Deploy Application
```bash
eb deploy
```

### Step 6: Check Status
```bash
eb status
eb health
```

### Step 7: View Logs
```bash
eb logs
```

## Manual AWS Console Deployment

1. **Upload ZIP to S3**
   - Go to S3 → Create Bucket → Upload `trading-app-aws.zip`

2. **Create EB Application**
   - Elastic Beanstalk → Create Application
   - Name: `trading-app`
   - Platform: Node.js 20
   - Upload Code from S3

3. **Configure Environment**
   - Environment Type: Load Balanced (for scalability)
   - Instance Type: t3.micro (free tier eligible)
   - Environment Properties: Set all secrets

4. **Create & Deploy**
   - Click "Create"
   - Wait 5-10 minutes for deployment

## HTTPS/SSL Setup

1. **Get SSL Certificate from ACM**
   - AWS Certificate Manager → Request Certificate
   - Validate domain ownership

2. **Update Load Balancer**
   - EB → Configuration → Load Balancer
   - Add HTTPS listener with SSL certificate

3. **Update .ebextensions/03_https.config**
   - Replace `REGION`, `ACCOUNT`, `CERTIFICATE_ID`

## Environment Variables Setup (Recommended)

Instead of hardcoding, use **AWS Systems Manager Parameter Store**:

```bash
# Store secrets
aws ssm put-parameter --name /trading-app/ANGEL_ONE_CLIENT_ID --value "P176266" --type SecureString
aws ssm put-parameter --name /trading-app/ANGEL_ONE_PASSWORD --value "password" --type SecureString
```

Then reference in `.ebextensions` using:
```yaml
environment:
  ANGEL_ONE_CLIENT_ID: !Sub '${ParameterStore:/trading-app/ANGEL_ONE_CLIENT_ID}'
```

## Troubleshooting

### Deployment Fails
1. Check logs: `eb logs`
2. SSH into instance: `eb ssh`
3. Check Node.js: `node --version`
4. Check npm: `npm --version`
5. Check app: `pm2 list`

### Application Crashes
```bash
eb ssh
tail -f /var/log/eb-activity.log
tail -f /var/log/nodejs.log
```

### Port Issues
Ensure `.ebextensions/01_nodejs.config` has:
```yaml
NodeCommand: "NODE_ENV=production node dist/index.js"
```

### Static Files Not Loading
Verify in `.ebextensions/01_nodejs.config`:
```yaml
staticfiles:
  /: dist/public/
```

## Scaling Configuration

Edit `.ebextensions` to add:
```yaml
auto-scaling:
  min_size: 2
  max_size: 10
  scale_up_threshold: 70 # CPU %
  scale_down_threshold: 30 # CPU %
```

## Database (Optional)

If using RDS:
1. Create RDS instance in AWS Console
2. Set `DATABASE_URL` environment variable
3. Run migrations on deployment

## Monitoring

Set up CloudWatch alarms for:
- CPU Utilization > 80%
- Memory Usage > 80%
- HTTP 5xx errors > 5/min
- Application Load Balancer target health

## Backup & Restore

```bash
# Create application version backup
eb appversion

# Revert to previous version
eb setenv --version-label previous-version-id
```

## Cost Optimization

1. Use t3.micro for free tier ($0/month)
2. Enable autoscaling to handle traffic spikes
3. Use CloudFront for static assets
4. Set up lifecycle policies for logs

## Next Steps

1. Test application: `eb open`
2. Monitor health dashboard
3. Set up domain name (Route 53)
4. Configure HTTPS
5. Set up monitoring & alerts

---

For more help:
- AWS EB Docs: https://docs.aws.amazon.com/elasticbeanstalk/
- EB CLI Docs: https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/eb-cli3.html
