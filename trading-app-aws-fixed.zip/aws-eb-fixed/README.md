# Trading App - AWS Elastic Beanstalk Deployment

## Quick Start (3 Steps)

### 1. Extract ZIP
```bash
unzip trading-app-aws-fixed.zip
cd eb-deploy
```

### 2. Deploy with EB CLI
```bash
# First time only
eb init -p "Node.js 20 running on 64bit Amazon Linux 2" --region us-east-1 --application-name trading-app

# Create environment
eb create trading-app-prod --instance-type t3.micro

# Or deploy to existing environment
eb deploy
```

### 3. Set Environment Variables (CRITICAL!)
Via AWS Console:
1. **Elastic Beanstalk → Environments → trading-app-prod**
2. **Configuration → Environment Properties**
3. Add these variables:
   ```
   ANGEL_ONE_CLIENT_ID = P176266
   ANGEL_ONE_PASSWORD = your_password
   ANGEL_ONE_TOTP_KEY = your_totp_key
   ZERODHA_API_KEY = your_key
   ZERODHA_SECRET_KEY = your_secret
   GEMINI_API_KEY = your_key
   ```
4. **Apply Changes** (takes 2-3 minutes)

---

## Check Deployment Status

```bash
# View environment health
eb health

# View recent logs
eb logs

# Open app in browser
eb open

# SSH into instance (for debugging)
eb ssh
```

---

## Troubleshooting

### Deployment fails or hangs
```bash
# Check all errors
eb logs --stream

# SSH and check app logs
eb ssh
tail -f /var/log/eb-engine.log
```

### App crashes after deployment
1. Check environment variables are set correctly
2. SSH and verify: `ps aux | grep node`
3. Check logs: `tail -f /var/log/nodejs.log`

### CORS errors
- Add your domain to CORS list in `server/index.ts`
- For EB: `https://your-env.elasticbeanstalk.com`

---

## What's Included

✅ **Node.js 20 Runtime**
✅ **Production Build** (pre-built assets)
✅ **Health Check Endpoint** (/health)
✅ **Static Files** Serving
✅ **Proper Error Handling**
✅ **CloudWatch Logging** (7 days retention)
✅ **Graceful Shutdown** (30 seconds)

---

## After Successful Deployment

1. Test health endpoint: `https://your-env.elasticbeanstalk.com/health`
2. Test API: `https://your-env.elasticbeanstalk.com/api/status`
3. Access app: `https://your-env.elasticbeanstalk.com`

---

## Production Checklist

- [ ] Environment variables configured in EB Console
- [ ] Health checks passing (green status)
- [ ] Application loads in browser
- [ ] WebSocket connection working (check browser console)
- [ ] Angel One API connects (check app logs)
- [ ] CORS working for your frontend domain

---

## Advanced: Scale Up

Edit `.ebextensions/01_node.config`:
```yaml
aws:autoscaling:asg:
  MinSize: 2
  MaxSize: 10
aws:autoscaling:trigger:
  MeasureName: CPUUtilization
  Statistic: Average
  Unit: Percent
  UpperThreshold: 70
  LowerThreshold: 20
```

Then redeploy:
```bash
eb deploy
```

---

For help: https://docs.aws.amazon.com/elasticbeanstalk/
